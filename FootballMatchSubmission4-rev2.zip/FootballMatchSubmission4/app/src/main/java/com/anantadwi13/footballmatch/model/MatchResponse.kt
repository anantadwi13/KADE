package com.anantadwi13.footballmatch.model

data class MatchResponse(
        val events: List<Match>
)