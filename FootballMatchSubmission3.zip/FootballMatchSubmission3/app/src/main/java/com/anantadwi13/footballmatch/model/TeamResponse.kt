package com.anantadwi13.footballmatch.model

data class TeamResponse(
        val teams: List<Team>
)