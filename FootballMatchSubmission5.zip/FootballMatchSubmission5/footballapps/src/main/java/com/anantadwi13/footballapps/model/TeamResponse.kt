package com.anantadwi13.footballapps.model

data class TeamResponse(
        val teams: List<Team>
)