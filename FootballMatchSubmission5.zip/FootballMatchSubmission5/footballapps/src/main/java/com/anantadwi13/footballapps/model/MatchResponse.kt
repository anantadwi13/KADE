package com.anantadwi13.footballapps.model

data class MatchResponse(
        val events: List<Match>,
        val event: List<Match>
)