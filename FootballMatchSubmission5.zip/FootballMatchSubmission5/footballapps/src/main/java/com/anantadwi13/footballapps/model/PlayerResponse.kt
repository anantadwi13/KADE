package com.anantadwi13.footballapps.model

data class PlayerResponse(
        val player: List<Player>
)